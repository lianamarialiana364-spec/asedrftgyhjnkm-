# CodeStart — melhorias adicionais

- Trilha aceita de 1 a 4 objetivos, remove duplicações e preserva progresso.
- Tutor conectado à API existente com fallback ao material, histórico e controles de erro (upgrade.js).
- Editor integrado existente com rascunhos, execução JS limitada por tempo e exportação.
- Central de estudos com dashboard, busca, metas, foco, anotações e backup (upgrade.js).
- Nova área de desafios com 6 questões, explicações e XP único por acerto.
- Nova área de certificados imprimíveis para cursos 100% concluídos.
- Melhorias de acessibilidade, responsividade e redução de animações.

Execute `pip install -r requirements.txt` e `python app.py`. A geração de respostas por IA requer configuração do provedor; sem ela o tutor consulta o material local. O progresso é guardado neste navegador.
