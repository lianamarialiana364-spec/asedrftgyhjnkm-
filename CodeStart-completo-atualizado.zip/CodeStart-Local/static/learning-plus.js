/* CodeStart Learning Plus — desafios, certificados e experiência de estudo */
'use strict';
(() => {
 const $=id=>document.getElementById(id), safe=window.escapeHTML|| (s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
 const bank=[
 {q:'Qual linguagem estrutura uma página web?',a:['HTML','CSS','SQL'],ok:0,why:'HTML define a estrutura e os elementos da página.'},
 {q:'Qual propriedade CSS altera a cor do texto?',a:['background','color','font-size'],ok:1,why:'color altera a cor do texto.'},
 {q:'Qual declaração JavaScript permite reatribuir um valor?',a:['const','let','import'],ok:1,why:'let permite reatribuição de valores.'},
 {q:'Qual comando SQL consulta dados?',a:['SELECT','INSERT','DELETE'],ok:0,why:'SELECT consulta registros de tabelas.'},
 {q:'Em Python, qual comando exibe uma mensagem?',a:['echo()','print()','show()'],ok:1,why:'print() exibe dados no terminal.'},
 {q:'O que é uma função?',a:['Um bloco reutilizável de instruções','Uma imagem','Um banco de dados'],ok:0,why:'Funções organizam código reutilizável.'}
 ];
 let current=0, answered=false;
 function data(){const s=Gamification.state; s.learningPlus ||= {answered:{},awarded:{},certificates:[]};return s.learningPlus;}
 function save(){Storage.save(Gamification.state)}
 function init(){
 const main=document.querySelector('main');if(!main||!window.Gamification||!window.Router)return;
 main.insertAdjacentHTML('beforeend',`<section id="view-desafios" class="view-section hidden lp-page"><div class="lp-card"><p class="lp-kicker">PRATIQUE O QUE APRENDEU</p><h1>Desafios de programação</h1><p>Responda às perguntas e receba explicações para cada resposta. Cada questão dá XP apenas na primeira resposta correta.</p><div class="lp-meter" id="lp-score" role="status"></div><div id="lp-question"></div><div class="lp-actions"><button class="lp-btn" id="lp-prev">Anterior</button><button class="lp-btn primary" id="lp-next">Próxima pergunta</button></div></div></section><section id="view-certificados" class="view-section hidden lp-page"><div class="lp-card"><p class="lp-kicker">SUAS CONQUISTAS</p><h1>Certificados de conclusão</h1><p>Certificados simbólicos do CodeStart para cursos com 100% das aulas concluídas. Não são credenciais profissionais.</p><div id="lp-cert-list"></div></div></section>`);
 const nav=document.querySelector('[data-route="trilha"]')?.parentElement;
 if(nav){nav.insertAdjacentHTML('beforeend','<button data-route="desafios" class="nav-link px-3 py-2 rounded-lg hover:bg-slate-800 transition">🧩 Desafios</button><button data-route="certificados" class="nav-link px-3 py-2 rounded-lg hover:bg-slate-800 transition">🏅 Certificados</button>');}
 const mobile=$('mobile-menu');if(mobile)mobile.insertAdjacentHTML('beforeend','<button data-route="desafios" class="block w-full text-left px-3 py-2 rounded-md">🧩 Desafios</button><button data-route="certificados" class="block w-full text-left px-3 py-2 rounded-md">🏅 Certificados</button>');
 document.querySelectorAll('[data-route="desafios"],[data-route="certificados"]').forEach(b=>b.addEventListener('click',()=>Router.go(b.dataset.route)));
 const go=Router.go.bind(Router);Router.go=v=>{go(v);if(v==='desafios')renderQuiz();if(v==='certificados')renderCertificates()};
 $('lp-prev').onclick=()=>{current=Math.max(0,current-1);renderQuiz()};$('lp-next').onclick=()=>{current=Math.min(bank.length-1,current+1);renderQuiz()};
 const tutor=$('tutor-user-input');if(tutor){tutor.setAttribute('aria-label','Digite sua dúvida de programação');tutor.setAttribute('maxlength','2000');tutor.setAttribute('autocomplete','off');const box=$('tutor-chat-box');box?.setAttribute('role','log');box?.setAttribute('aria-live','polite');box?.setAttribute('aria-relevant','additions');}
 const trail=$('duolingo-path-container');if(trail)trail.setAttribute('aria-label','Etapas da sua trilha de aprendizagem');
 const original=TrilhaPage.render.bind(TrilhaPage);TrilhaPage.render=()=>{original();document.querySelectorAll('[data-course-node]').forEach(b=>{b.setAttribute('aria-label','Abrir curso '+(b.nextElementSibling?.textContent||''));b.setAttribute('title','Abrir curso')})};
 renderQuiz();renderCertificates();
 }
 function renderQuiz(){const d=data(),q=bank[current],prior=d.answered[current];$('lp-score').textContent=`Questão ${current+1} de ${bank.length} · ${Object.values(d.answered).filter(x=>x.correct).length} acertos`;answered=prior!==undefined;
 $('lp-question').innerHTML=`<h2>${safe(q.q)}</h2><div class="lp-options">${q.a.map((a,i)=>`<button class="lp-option" data-answer="${i}" ${answered?'disabled':''}>${safe(a)}</button>`).join('')}</div><p id="lp-feedback" role="status">${answered?(prior.correct?'✓ Correto. ':'Resposta registrada. ')+safe(q.why):'Escolha uma alternativa.'}</p>`;
 $('lp-question').querySelectorAll('[data-answer]').forEach(b=>b.onclick=()=>{const ok=Number(b.dataset.answer)===q.ok;d.answered[current]={correct:ok};if(ok&&!d.awarded[current]){d.awarded[current]=true;Gamification.addXP(15,'Desafio concluído')}save();renderQuiz()});
 $('lp-prev').disabled=current===0;$('lp-next').disabled=current===bank.length-1;
 }
 function renderCertificates(){const s=Gamification.state;const done=new Set(s.completedLessons||[]);const completed=COURSES.filter(c=>c.lessons.length&&c.lessons.every((_,i)=>done.has(`${c.id}-${i}`)));$('lp-cert-list').innerHTML=completed.length?completed.map(c=>`<article class="lp-cert"><div><strong>${safe(c.name)}</strong><p>${c.lessons.length} aulas concluídas</p></div><button class="lp-btn" data-cert="${safe(c.id)}">Imprimir certificado</button></article>`).join(''):'<p>Conclua todas as aulas de um curso para liberar seu certificado.</p>';
 $('lp-cert-list').querySelectorAll('[data-cert]').forEach(b=>b.onclick=()=>{const c=completed.find(x=>x.id===b.dataset.cert);if(!c)return;const name=String(s.studentName||'Estudante CodeStart').slice(0,100);const w=window.open('','_blank','width=900,height=700');if(!w){alert('Permita janelas pop-up para imprimir o certificado.');return;}w.document.write(`<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Certificado CodeStart</title><style>body{font-family:Arial;text-align:center;padding:8vh 6vw;color:#172554;border:12px double #1d4ed8;min-height:70vh}h1{font-size:46px}h2{font-size:32px}p{font-size:20px}.note{font-size:13px;margin-top:65px}</style><h1>CodeStart</h1><h2>Certificado de conclusão</h2><p>Certificamos que</p><h2>${safe(name)}</h2><p>concluiu as ${c.lessons.length} aulas do curso</p><h2>${safe(c.name)}</h2><p>${new Date().toLocaleDateString('pt-BR')}</p><p class="note">Registro de conclusão na plataforma CodeStart. Não equivale a certificação profissional.</p></html>`);w.document.close();w.focus();setTimeout(()=>w.print(),350)});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,100));else setTimeout(init,100);
})();
