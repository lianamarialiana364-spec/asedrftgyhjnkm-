# Melhorias na experiência de aprendizagem

- O seletor de trilha agora mantém apenas um objetivo por vez, conforme exigido pela API.
- A trilha mostra o estado de cada curso e permite revisitar ou iniciar cursos sem bloqueios artificiais.
- A mensagem inicial do tutor informa corretamente sobre IA e fallback para material didático.
- O histórico restaurado do tutor usa texto escapado para reduzir riscos de HTML inseguro.
- O backup do histórico do tutor importa texto simples com limites de tamanho.

## Executar
Instale as dependências com `pip install -r requirements.txt` e inicie com `python app.py`.

## Validação
Sintaxe Python compilada; JavaScript verificado com Node. Testes de integração não executados neste ambiente por falta do Flask.
